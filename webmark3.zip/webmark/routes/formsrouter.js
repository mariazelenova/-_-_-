import { Router } from 'express';
import multer from 'multer';
import { getTestByName } from '../lib/testbdconnector.js';


const upload = multer();

export const formsRouter = Router();



formsRouter.get('/', (req, res, next) => {

    res.render(
      'textform',
      { title: ' 1' }
    );
  
  });
  
  
  
formsRouter.post('/:name', (req, res, next) => {
    console.log("post"+JSON.stringify(req.body));
    res.render(
      'message',
      { title: req.params.name }
    );
  
});


formsRouter.post('/', upload.none(),(req, res, next) => {
  console.log("post"+JSON.stringify(req.body));
  console.log("post" + req.body.name);

  let payload = JSON.stringify({foo: 'bar'});
  let jsonHeaders = new Headers({
    'Content-Type': 'application/json'
    });
  fetch('http://localhost:8083', {
    method: 'POST',
    body: payload,
    headers: jsonHeaders
    });


  const f = req.body.testname
  const ff = getTestByName(f)
  res.render(
    'textform',
    { title: ff, testid: f}
  );

});

