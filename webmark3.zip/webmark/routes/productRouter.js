import { Router } from 'express';



export const productRouter = Router();



productRouter.get('/', (req, res, next) => {

    const xValues1 = [100,200,300,400,500,600,700,800,900,1000]; 

   
   
    let xAxis = "";
    for (let a in xValues1) { 
      xAxis = xValues1[a].toString()+",";
    }

    res.render(
      'product',
      { 
        graphvisible: false,
        buttonvisible: true,
        text: "3 4 5 6",
        helpers: {
          helperdata1() { return 'testdata4'; },
          helperdata2() { return 'testdata5'; }
      }
      }
    );
  
  });