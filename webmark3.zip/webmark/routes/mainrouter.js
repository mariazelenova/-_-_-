import { Router } from 'express';

export const mainRouter = Router();

mainRouter.get('/', (req, res,next) => {
res.render(
    'home',{}
);
});