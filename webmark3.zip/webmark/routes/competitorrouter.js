import { Router } from 'express';


export const competitorRouter = Router();



competitorRouter.get('/', (req, res, next) => {

    res.render(
      'product2',
      { graphvisible: true,
        buttonvisible: false,
        temt1: "3000 4000 5000 6000 7000 3000 4000 5000 6000 7000",
        temt2: "3000 4000 5000 4000 7000 3000 4000 5000 6000 7000",
        temt3: "3000 4000 5000 6000 8000 3000 4000 5000 6000 7000",
      }
    );
  
  });