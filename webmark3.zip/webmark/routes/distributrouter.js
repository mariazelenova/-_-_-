import { Router } from 'express';


export const distributRouter = Router();



distributRouter.get('/', (req, res, next) => {

    res.render(
      'product',
      { graphvisible: true,
        buttonvisible: false,
      }
    );
  
  });