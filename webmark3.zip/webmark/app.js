import express from 'express';
import { engine } from 'express-handlebars';;
import { fileURLToPath } from 'url';
import { dirname, sep } from 'path';
import { formsRouter } from './routes/formsrouter.js';
import { mainRouter } from './routes/mainrouter.js';
import { productRouter } from './routes/productRouter.js';
import { competitorRouter } from './routes/competitorrouter.js';
import { distributRouter } from './routes/distributrouter.js';
import { create } from 'express-handlebars';

const __dirname = dirname(fileURLToPath( import.meta.url )) + sep;

const app = express();

const hbs = create({
    // Specify helpers which are only registered on this instance.
    helpers: {
        helperdata1() { return 'testdata1'; },
        helperdata2() { return 'testdata2'; }
    }
  });
// Настройка механизма представлений Handlebars.
app.engine('handlebars', hbs.engine);
app.set('view engine', 'handlebars');
app.set('views', './views');

app.set('port', process.env.PORT || 3000);

app.use(express.static(__dirname + '/public'))

// custom 500 page
app.use(function(err, req, res, next){
    console.error(err.stack);
    res.type('text/plain');
    res.status(500);
    res.send('500 - Server Error');
});


app.use('/', mainRouter);
app.use('/textforms', formsRouter);
app.use('/product', productRouter);
app.use('/competitor', competitorRouter);
app.use('/distribut', distributRouter);

    // custom 404 page
app.use(function(req, res, next){
    res.type('text/plain');
    res.status(404);
    res.send('404 - Not Found');
});
app.listen(app.get('port'), function(){
console.log( 'Express started on http://localhost:' +
app.get('port') + '; press Ctrl-C to terminate.' );
});